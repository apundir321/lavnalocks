package com.alight.dcapp.dcapplication;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.hewitt.cat.tba.properties.ConfigurationManager;
import com.hewitt.cat.tba.properties.PoolManager;
import com.hewitt.cat.tba.properties.PrprCmps;

//import org.apache.commons.lang.StringUtils;

/**
 * Servlet Filter implementation class AFFilter
 */
@Component
public class AFFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AFFilter() {
        // TODO Auto-generated constructor stub
    }
    
    private Pattern pattern = Pattern.compile("\\$\\{(.*?)\\}");

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest aServletRequest, ServletResponse aServletResponse, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
//		System.setProperty("prprConfigRoot", "C:\\Apps\\Benefits\\Portal\\config");
//		System.setProperty("lifecycle_phase", "dv");
		System.out.println("inside filter ********!!!!!");
//		 init();
//		ServletContext application=aServletRequest.getServletContext();
//		String appUrl = application.getInitParameter("app_url");
//		System.out.println(appUrl+" ****");
//		
//		String gatewayUrl = application.getInitParameter("gatewayUrl");
//		System.out.println(gatewayUrl+" ****");
		// pass the request along the filter chain
//		 try
//	        {
//	            HttpServletRequest request = (HttpServletRequest) aServletRequest;
//	            String uri = request.getRequestURI();
////	            System.out.println(uri+ "&&&&&7" );
//	            HttpServletResponse httpResponse = (HttpServletResponse) aServletResponse;
//	            
//	            if ((uri!=""  && uri != null) && (uri.contains("-es5.js") || 
//	            		uri.contains("-es2015.js"))) {
//	            	boolean adoptAFng8 = false;
//	            	boolean adoptAFngEight = false;
//	            	boolean isCookieFound = false;
//	            	try {
//	            		String requestedNameURL = uri.substring(uri.lastIndexOf("/")+1, uri.length());
//	                	if ((requestedNameURL!=""  && requestedNameURL != null) && (!requestedNameURL.contains( "runtime") && !requestedNameURL.contains("polyfill")
//	                			&& !requestedNameURL.contains( "main"))) {
//	                		String cmLineage = "1.0";
//	                       
//	                        /** This cookie is set under portal_normal.vm file : to read Lineage */
//	                		try {
//	                			Cookie[] requestCookies = request.getCookies();
//	                        	if (requestCookies!=null) {
//	                				for (Cookie cookie : requestCookies) {
//	                	        	   	if (cookie.getName().equals("upn_af_cookie") && cookie.getValue() != null) {
//	                	        	   		isCookieFound = true; 
//	                		        	    String allLineages[] = cookie.getValue().split("\\$");
//	                		        	    if (allLineages.length > 1) {
//	                		        	    	cmLineage = allLineages[0];
//	                		        	    	adoptAFng8  = Boolean.valueOf(allLineages[1]);
//	                		        	    	break;
//	                		        	    }
//	                					}
//	                				}
//	                			}
//	                        } catch (Exception e) {
////	                        	ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing Cookies From Request for AF Ng8",
////	                        			"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
//	                        	cmLineage = "1.0";
//	                        }
//	                		if(isCookieFound){
//	                			adoptAFngEight = adoptAFng8;
//	                		}else{
//	                			adoptAFngEight = true;
//	                		}
//	                		
//	                		if (adoptAFngEight) {
//	                			String angAppPropertyUrl  = "";
//	                			try
//	                            {
//	                				angAppPropertyUrl = "https://upoint-dv.alight.com/UpointDevNg8/";
//	                                if((angAppPropertyUrl == "" || angAppPropertyUrl == null)){
//	                                          angAppPropertyUrl = "https://upoint-dv.alight.com/UpointDevNg8/upoint-dev/";
//	                                } 
//	                                String generatedURL = angAppPropertyUrl + requestedNameURL;
//	                                httpResponse.sendRedirect(generatedURL);
//	                                return;
//	                            }
//	                            catch(Exception e)
//	                            {
////	                            	ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing uri inside if block.",
////	                            			"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
//	                            }
//	                		}
//	                	}
//	            	} catch (Exception e) {
////	            		ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing AF NG8 Logic",
////	                			"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
//	            	}
//	            }
//	            
//	            if (uri.contains("chunk.js"))
//	            {
//	            	System.out.println("inside chunk");
//	                String angAppPropertyUrl = "";
//	                try
//	                {
//	                    angAppPropertyUrl = "https://upoint-dv.alight.com/upoint-dev/";
//	                    if((angAppPropertyUrl=="" || angAppPropertyUrl==null)){
//	                    	angAppPropertyUrl = "https://upoint-dv.alight.com/upoint-hybrid-dev/";
//	                   } 
//	                    String generatedURL = angAppPropertyUrl + uri.substring(uri.lastIndexOf("/")+1, uri.length());
//	                    httpResponse.sendRedirect(generatedURL);
//	                    
//	                    return;
//	                }
//	                catch(Exception e)
//	                {
////	                	ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing uri inside if block.",
////	                            "AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
////	                    angAppPropertyUrl = "https://upoint-dv.alight.com/";
//	                }
//	            } 
//	            chain.doFilter(aServletRequest, aServletResponse);     
//	        }
//	        catch (Exception e)
//	        {
//	        	e.printStackTrace();
////	            ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing  filter.",
////	                    "AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
//	        }
		
		
		
		
		 try
	        {
	            HttpServletRequest request = (HttpServletRequest) aServletRequest;

	           
	            String uri = request.getRequestURI();
	            HttpServletResponse httpResponse = (HttpServletResponse) aServletResponse;
	            
	            if ((uri!=""  && uri != null) && (uri.contains("-es5.js") || 
	            		uri.contains("-es2015.js"))) {
	            	boolean adoptAFng8 = false;
	                boolean thriftFedDc = false;
	            	boolean adoptAFngEight = false;
	            	boolean isCookieFound = false;
	            	try {
	            		String requestedNameURL = uri.substring(uri.lastIndexOf("/")+1, uri.length());
	            		if ((requestedNameURL!=""  && requestedNameURL != null) && (!requestedNameURL.contains( "runtime") && !requestedNameURL.contains("polyfill")
	                			&& !requestedNameURL.contains( "main"))) {
	                		String cmLineage = "1.0";
	                       
	                        /** This cookie is set under portal_normal.vm file : to read Lineage */
	                		try {
	                			Cookie[] requestCookies = request.getCookies();
	                			if (requestCookies!=null) {
	                				for (Cookie cookie : requestCookies) {
	                	        	   	if (cookie.getName().equals("upn_af_cookie") && cookie.getValue() != null) {
	                	        	   		isCookieFound = true; 
	                		        	    String allLineages[] = cookie.getValue().split("\\$");
	                		        	    if (allLineages.length > 1) {
	                		        	    	cmLineage = allLineages[0];
	                		        	    	adoptAFng8  = Boolean.valueOf(allLineages[1]);
	                		        	    }
	                					}
	                                    if (cookie.getName().equals("upn_thrift_cookie") && cookie.getValue() != null) {
	                                        isCookieFound = true;
	                		        	    String allLineages[] = cookie.getValue().split("\\$");
	                		        	    if (allLineages.length > 1) {
	                		        	    	cmLineage = allLineages[0];
	                		        	    	thriftFedDc  = Boolean.valueOf(allLineages[1]);
	                		        	    }
	                					}
	                				}
	                			}
	                        } catch (Exception e) {
								/*
								 * ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
								 * "Error processing Cookies From Request for AF Ng8", "AFFilter.doFilter()", e,
								 * ErrorLogEvent.ERROR_SEVERITY);
								 */
	                        	cmLineage = "1.0";
	                        }
	                        if(isCookieFound){
	                			adoptAFngEight = adoptAFng8;
	                		}else{
	                			//adoptAFngEight = ExpressionsLocalServiceUtil.evaluateExpression(cmLineage, "ADOPT_AF_NG8_MASTER", false);
	                           // thriftFedDc = ExpressionsLocalServiceUtil.evaluateExpression(cmLineage, "IS_FED_APP_ENABLED", false);
	                			adoptAFngEight = false;
	                			thriftFedDc = true;
	                		}
	                		String angAppPropertyUrl  = "";
	                        
	                        if(thriftFedDc) {
	                        try {
	                        	HroPropertyServiceUtil hroPropertyServiceUtil = new HroPropertyServiceUtil(); 
	                                angAppPropertyUrl = (String) hroPropertyServiceUtil.getProperty("portal","AF_FED_DC_APP_URL",request);
	                                if(angAppPropertyUrl ==null || angAppPropertyUrl.equals("")){
	                                          angAppPropertyUrl = (String)hroPropertyServiceUtil.getProperty("portal","AF_APP_URL_NG8",request);
	                                }
	                                String generatedURL = angAppPropertyUrl + requestedNameURL;
	                                    httpResponse.sendRedirect(generatedURL);
	                                    return;
	                            }
	                        catch(Exception e)
	                            {
	                            	//ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing uri inside if block.",
	                            	//		"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
	                            }
	                        }
	                            
//	                		else if (adoptAFngEight) {
//	                			try
//	                            {
//	                				angAppPropertyUrl = (String) HROPropertiesLocalServiceUtil.getProperty("portal","AF_APP_URL_NG8");
//	                                if(angAppPropertyUrl==null || angAppPropertyUrl.equals("")){
//	                                          angAppPropertyUrl = (String)HROPropertiesLocalServiceUtil.getProperty("portal","AF_APP_URL");
//	                                } 
//	                                String generatedURL = angAppPropertyUrl + requestedNameURL;
//	                                httpResponse.sendRedirect(generatedURL);
//	                                return;
//	                            }
//	                            catch(Exception e)
//	                            {
////	                            	ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing uri inside if block.",
////	                            			"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
//	                            }
//	                		}
	                	}
	            	} catch (Exception e) {
//	            		ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing AF NG8 Logic",
//	                			"AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
	            	}
	            }
	            
	            if (uri.contains("chunk.js"))
	            {
	                String angAppPropertyUrl = "";
	                try
	                {
	                	HroPropertyServiceUtil hroPropertyServiceUtil = new HroPropertyServiceUtil();
	                    angAppPropertyUrl = (String) hroPropertyServiceUtil.getProperty("portal","AF_FED_DC_APP_URL",request);
	                    if(angAppPropertyUrl==null || angAppPropertyUrl.equals("")){
	                    	angAppPropertyUrl = (String)hroPropertyServiceUtil.getProperty("portal","APP_URL",request);
	                   } 
	                    String generatedURL = angAppPropertyUrl + uri.substring(uri.lastIndexOf("/")+1, uri.length());
	                    httpResponse.sendRedirect(generatedURL);
	                    
	                    return;
	                }
	                catch(Exception e)
	                {
//	                	ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing uri inside if block.",
//	                            "AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
	                    angAppPropertyUrl = "https://upoint-dv.alight.com/";
	                }
	            } 
	            chain.doFilter(aServletRequest, aServletResponse);     
	        }
	        catch (Exception e)
	        {
//	            ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error processing  filter.",
//	                    "AFFilter.doFilter()", e, ErrorLogEvent.ERROR_SEVERITY);
	        }

		
//		chain.doFilter(request, response);
	}
	
	private Object decodeProperties(String aPropertyName, Object property)
	{
		// Object property
		Object propertyValue= property;
		if (propertyValue != null && propertyValue instanceof String)
		{
			StringBuffer sb = new StringBuffer();
			Matcher matcher = pattern.matcher(propertyValue.toString());
			while (matcher.find())
			{
				try
				{
					String sysProperty = matcher.group(1);
					String sysPropertyValue = System.getProperty(sysProperty);

					matcher.appendReplacement(sb,
							Matcher.quoteReplacement(sysPropertyValue));
				}
				catch (Exception e)
				{
					// no need to log exception here because LOGOUT_URL_CM
					// contains ${clientId} token and raise exception. 
				}
			}
			matcher.appendTail(sb);

			propertyValue = sb.toString();
			//hashtable.put(aPropertyName, propertyValue);
		}
		return propertyValue;
	}
	
	
	  private void init()
	    {
	        String prprConfigRoot = System.getProperty("prprConfigRoot");
//	        if (DebugLogEventHelper.isEnabled(this.getClass().getName()))
//	        {
//	            String content = new StringBuilder(80).append("[prprConfigRoot=").append(prprConfigRoot)
//	                    .append("]").toString();
//	            DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Inside", "init", content);
//	            content = null;
//	        }

	        try
	        {
	            ConfigurationManager.init(prprConfigRoot);
	        }
	        catch (FileNotFoundException e)
	        {

//	            ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "IOException", "init", e, "",
//	                    ErrorLogEvent.ERROR_SEVERITY);
	        	e.printStackTrace();
	        }
	        catch (IOException e)
	        {

//	            ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "IOException", "init", e, "",
//	                    ErrorLogEvent.ERROR_SEVERITY);
	        	e.printStackTrace();
	        }
	    }
	
	private PrprCmps getPrprCmps(String aLineage)
	{
		PrprCmps prprCmps=null;
		try
        {
        	// Attempt to retrieve the runtime properties against the client.
            // NOTE: We convert lineage to lower-case since TOMI generates lower-case file system 
        	// (i.e., windows file systems are case-insensitive whereas linux are case-sensitive).
            prprCmps = PoolManager.getInstance().getProperty(aLineage.toLowerCase());
        }
        catch (Exception ex)
        {
        	 if("portal".equalsIgnoreCase(aLineage)){
//        		 ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "PropertyException",
//                         "getPrprCmps(String aLineage)", ex, "", ErrorLogEvent.ERROR_SEVERITY);
        	 }
        	 else{
        		 
        	     // If client runtime properties does not exist, try unaltered lineage.
	            if((prprCmps == null) && !aLineage.equals(aLineage.toLowerCase())) 
	            {
	                try
	                {
	                    prprCmps = PoolManager.getInstance().getProperty(aLineage);
	                }
	                catch (Exception baseEx)
	                {
//	                	String parentLineage=getParentLineage(aLineage);
//		            	prprCmps=getPrprCmps(parentLineage);
	                }
	            }        	
	            else
	            {
		            if(!"portal".equalsIgnoreCase(aLineage))
		            {
//		            	String parentLineage=getParentLineage(aLineage);
//		            	prprCmps=getPrprCmps(parentLineage);
		            }
		                       	
//		            if (DebugLogEventHelper.isEnabled(this.getClass().getName()))
//	                {
//	                    String exitContent = new StringBuilder(80).append("[aLineage=").append(aLineage)
//	                            .append("[Exception=").append(ex.getMessage()).append("]").toString();
//	                    DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Exit", "getPrprCmps",
//	                            exitContent);
//	                    exitContent = null;
//	                }
	            	
	            }
          }
        }
		return prprCmps;
	}

	

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
