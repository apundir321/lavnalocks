package com.alight.dcapp.dcapplication;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.hewitt.cat.tba.properties.ConfigurationManager;
import com.hewitt.cat.tba.properties.PoolManager;
import com.hewitt.cat.tba.properties.PrprCmps;

public class HroPropertyServiceUtil {
	
	 private static Pattern pattern = Pattern.compile("\\$\\{(.*?)\\}");
	
	public HroPropertyServiceUtil()
	{
		System.setProperty("prprConfigRoot", "C:\\Apps\\Benefits\\Portal\\config");
		System.setProperty("lifecycle_phase", "dv");
		init();
	}
	
	public  Object decodeProperties(String aPropertyName, Object property)
	{
		// Object property
		Object propertyValue= property;
		if (propertyValue != null && propertyValue instanceof String)
		{
			StringBuffer sb = new StringBuffer();
			Matcher matcher = pattern.matcher(propertyValue.toString());
			while (matcher.find())
			{
				try
				{
					String sysProperty = matcher.group(1);
					String sysPropertyValue = System.getProperty(sysProperty);

					matcher.appendReplacement(sb,
							Matcher.quoteReplacement(sysPropertyValue));
				}
				catch (Exception e)
				{
					// no need to log exception here because LOGOUT_URL_CM
					// contains ${clientId} token and raise exception. 
				}
			}
			matcher.appendTail(sb);

			propertyValue = sb.toString();
//			hashtable.put(aPropertyName, propertyValue);
		}
		return propertyValue;
	}
	
	 public  Object getRequestProperty(String aLineage, String aPropertyName)
	    {
	       
	        PrprCmps prprCmps = null;
	        Object property = null;

	        prprCmps = getPrprCmps(aLineage);
	        
	        Map hashtable = prprCmps.getRequestProperties();
	        property = hashtable.get(aPropertyName);      
	        property = decodeProperties(aPropertyName, property);
	       
	        return property;
	    }
	 
	 
	    public Object getProperty(String aLineage, String aPropertyName,HttpServletRequest request)
	    {
	        Object property = null;

	        property = getRequestProperty(aLineage, aPropertyName);

	        if (property == null)
	        {
	            property = getPropertyFromHttpSession(aLineage, aPropertyName,request);
	        }

	        if (property == null)
	        {
	            property = getSessionProperty(aLineage, aPropertyName);
	            if (property != null)
	            {
	                addPropertyToHttpSession(aLineage, aPropertyName, property,request);
	            }
	        }
	        return property;
	    }
	    
	    private void addPropertyToHttpSession(String aLineage, String aPropertyName, Object value,HttpServletRequest request)
	    {
	       
	        
	        if (request != null)
	        {
	            HttpSession httpSession = request.getSession();
	            if (httpSession != null)
	            {
	                Hashtable hroSessionProperties = (Hashtable) httpSession.getAttribute(aLineage + "_"
	                        + "HRO_SESSION_SOURCE");
	                if (hroSessionProperties != null)
	                {
	                    hroSessionProperties.put(aPropertyName, value);

	                }
	                else
	                {
	                    hroSessionProperties = new Hashtable<String, Object>();
	                    hroSessionProperties.put(aPropertyName, value);
	                }
	                httpSession.setAttribute(aLineage + "_"
	                        + "HRO_SESSION_SOURCE", hroSessionProperties);
	            }
	           
	        }
	        

	     
	    }
	    
	    private Object getSessionProperty(String aLineage, String aPropertyName)
	    {
	        PrprCmps prprCmps = null;
	        Object property = null;

	        prprCmps = getPrprCmps(aLineage);
	        
	        Map hashtable = prprCmps.getSessionProperties();
	        property = hashtable.get(aPropertyName);        
	        property = decodeProperties(aPropertyName, property);
	        
	       
	        return property;
	    }
	    
	    
	 
	 private Object getPropertyFromHttpSession(String aLineage, String aPropertyName,HttpServletRequest request)
	    {
	       
	        Object property = null;
	        
//	        HttpServletRequest request = RequestProvider.getRequest();
	        if (request != null)
	        {
	            HttpSession httpSession = request.getSession();
	            if (httpSession != null)
	            {
	                Hashtable hroSessionProperties = (Hashtable) httpSession.getAttribute(aLineage + "_"
	                        + "HRO_SESSION_SOURCE");
	                if (hroSessionProperties != null)
	                {
	                    property = hroSessionProperties.get(aPropertyName);
	                }
	            }
	           
	        }
	       

	       
	        return property;
	    }

	
	  public void init()
	    {
	        String prprConfigRoot = System.getProperty("prprConfigRoot");
	        try
	        {
	            ConfigurationManager.init(prprConfigRoot);
	        }
	        catch (FileNotFoundException e)
	        {
	        	e.printStackTrace();
	        }
	        catch (IOException e)
	        {
	        	e.printStackTrace();
	        }
	    }
	
	public  PrprCmps getPrprCmps(String aLineage)
	{
		PrprCmps prprCmps=null;
		try
        {
        	// Attempt to retrieve the runtime properties against the client.
            // NOTE: We convert lineage to lower-case since TOMI generates lower-case file system 
        	// (i.e., windows file systems are case-insensitive whereas linux are case-sensitive).
            prprCmps = PoolManager.getInstance().getProperty(aLineage.toLowerCase());
        }
        catch (Exception ex)
        {
        	 if("portal".equalsIgnoreCase(aLineage)){
//        		 ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "PropertyException",
//                         "getPrprCmps(String aLineage)", ex, "", ErrorLogEvent.ERROR_SEVERITY);
        	 }
        	 else{
        		 
        	     // If client runtime properties does not exist, try unaltered lineage.
	            if((prprCmps == null) && !aLineage.equals(aLineage.toLowerCase())) 
	            {
	                try
	                {
	                    prprCmps = PoolManager.getInstance().getProperty(aLineage);
	                }
	                catch (Exception baseEx)
	                {
//	                	String parentLineage=getParentLineage(aLineage);
//		            	prprCmps=getPrprCmps(parentLineage);
	                }
	            }        	
	            else
	            {
		            if(!"portal".equalsIgnoreCase(aLineage))
		            {
//		            	String parentLineage=getParentLineage(aLineage);
//		            	prprCmps=getPrprCmps(parentLineage);
		            }
		                       	
//		            if (DebugLogEventHelper.isEnabled(this.getClass().getName()))
//	                {
//	                    String exitContent = new StringBuilder(80).append("[aLineage=").append(aLineage)
//	                            .append("[Exception=").append(ex.getMessage()).append("]").toString();
//	                    DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Exit", "getPrprCmps",
//	                            exitContent);
//	                    exitContent = null;
//	                }
	            	
	            }
          }
        }
		return prprCmps;
	}


}
