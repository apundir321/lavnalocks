package com.alight.dcapp.dcapplication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class IndexController {
	
	@GetMapping({"/", "/hello"})
    public String hello(HttpServletRequest request, HttpServletResponse response,Model model) {
       
        HroPropertyServiceUtil propertyServiceUtil = new HroPropertyServiceUtil();
        String appUrl = (String)propertyServiceUtil.getProperty("portal", "AF_FED_DC_APP_URL",request);
        String gatewayUrl = (String)propertyServiceUtil.getProperty("portal", "ZUUL_PROXY",request);
        model.addAttribute("appUrl", appUrl);
        model.addAttribute("gatewayUrl", gatewayUrl);
        System.out.println(appUrl+" &&&&");
        return "index";
    }
	
}
