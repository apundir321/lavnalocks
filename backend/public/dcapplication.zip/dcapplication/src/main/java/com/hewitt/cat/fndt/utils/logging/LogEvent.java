package com.hewitt.cat.fndt.utils.logging;

/* =============================================================================
 * 
 * Copyright (c) 2003-2005 Hewitt Associates, LLC. 100 Half Day Road, Lincolnshire, Illinois, 60069, U.S.A.
 * All rights reserved.
 * 
 * This program contains proprietary and confidential information and trade secrets of Hewitt Associates LLC.
 * This program may not be duplicated, disclosed or provided to any third parties without the prior written
 * consent of Hewitt Associates LLC. Disassembly or decompilation of the software and reverse engineering of
 * the object code are prohibited.
 * 
 * ============================================================================= */



import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
//import org.apache.commons.lang.time.FastDateFormat;

/**
 * This is the LogEvent class that holds all the information pertinent to a logging event.
 * 
 * @hahistory 09/09/03 a29362 created<br>
 * @hahistory 11/03/2003 a29362 Removed unused imports.
 * @hahistory 12/05/2003 a29362 Added modifyAttribute method.
 * @hahistory 01/19/2004 a29362 Changed the format of the event date, modified the attribute names and
 * protected the get methods for the attributes.
 * @hahistory 03/08/2004 a29362 Fix date format.
 * @hahistory 03/29/2004 a29362 Added exceptions.
 * @hahistory 07/19/2004 a29362 Added toString method.
 * @hahistory 07/20/2004 a29362 Updated to use a LinkedHashMap.
 * @hahistory 08/23/2004 a29362 Added constant for internal events attribute.
 * @hahistory 12/15/2004 a29362 Increased size of event Id field to 10 digits.
 * @since 1.0
 */
public class LogEvent
{

    /**
     * Unique identifier for the event.
     * 
     * @since 1.0
     */
    public static final String EVENT_ID_ATTRIB = "Event Id";

    /**
     * Event timestamp.
     * 
     * @since 1.0
     */
    public static final String TIME_ATTRIB = "Time";

    /**
     * Internal events attribute.
     * 
     * @since 1.0
     */
    public static final String INTERNAL_EVENTS_ATTRIB = "internalEvents";

    /**
     * Maximum length of the event Id attribute.
     * 
     * @since 1.0
     */
    public static final int EVENT_ID_LENGTH = 10;
    
//    private static FastDateFormat fdf=FastDateFormat.getInstance("yyyy-MM-dd-HH.mm.ss.SSS000");


    /**
     * This field holds a list of events that are associated with the main event so that we can show the
     * chaining of events when we log them. This is a private field.
     * 
     * @since 1.0
     */
    private ArrayList mAssocEvents = null;

    /**
     * This field holds a map of attributes that are associated with the event. This facilitates the look
     * up/addition of attributes based on key values. This is a private field.
     * 
     * @since 1.0
     */
    private LinkedHashMap mAttribMap = null;

    /**
     * The constructor creates a LogEvent object and associates an eventId and an eventDate with it with it.
     * 
     * @since 1.0
     */
    public LogEvent()
    {
        super();

        String eventId = genEventId();
      
        // removed addAttribute call and added its content for PMD 
        getAttributeMap().put(EVENT_ID_ATTRIB, eventId);
       

        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS000");
//        getAttributeMap().put(TIME_ATTRIB, fdf.format(new Date()));
      
    }

    /**
     * This method adds an event to the list of associated events for the current event.
     * 
     * @param aEvent Description
     * @throws LoggingException Exception thrown if event to be associated is null.
     * @since 1.0
     */
    public void addAssociatedEvent(LogEvent aEvent)
    {

        if (aEvent == null)
        {
            throw new LoggingException("Event to be associated cannot be null.");
        }

        getAssociatedEvents().add(aEvent);
    }

    /**
     * This method adds an attribute of the current event.
     * 
     * @param aKey The key that denotes the attribute.
     * @param aValue The object that represents the attribute value.
     * @throws LoggingException Exception thrown if key is null.
     * @since 1.0
     */
    public void addAttribute(String aKey, Object aValue)
    {

        if (aKey == null)
        {
            throw new LoggingException("Key for the attribute cannot be null");
        }

        // add the attribute to the hashmap
        getAttributeMap().put(aKey, aValue);
    }

    /**
     * Checks if the specificed attribute exists in the attribute list of the log event.
     * 
     * @since 1.0
     * @param aAttribName Name of the attribute being looked for.
     * @return boolean True if attribute exists, false otherwise.
     */
    public boolean containsAttribute(String aAttribName)
    {

        return getAttributeMap().containsKey(aAttribName);
    }

    /**
     * Returns a string of internal event ids associated with an instance of the log event.
     * 
     * @since 1.0
     * @return String Comma delimited string of event ids.
     */
    public String getAssociatedEventIds()
    {

        // get all the events associated with the LogEvent being rendered.
        LogEvent[] assocEvents = getAssociatedEventsList();

        // build a string of these internal events.
        String internalEvents = "";

        if (assocEvents.length != 0)
        {
            internalEvents = "[";
        }

        for (int iIdx = 0; iIdx < assocEvents.length; iIdx++)
        {

            LogEvent event = (LogEvent) assocEvents[iIdx];

            if (iIdx == 0)
            {
                internalEvents = internalEvents + event.getEventId();
            }
            else
            {
                internalEvents = internalEvents + "," + event.getEventId();
            }
        }

        if (assocEvents.length != 0)
        {
            internalEvents = internalEvents + "]";
        }

        return internalEvents;

    }

    /**
     * This method returns the list of associated events for the current event.
     * 
     * @return ArrayList that contains the associated events
     * @since 1.0
     */
    public LogEvent[] getAssociatedEventsList()
    {

        ArrayList alEvents = getAssociatedEvents();

        LogEvent[] events = new LogEvent[alEvents.size()];

        for (int i = 0; i < alEvents.size(); i++)
        {
            events[i] = (LogEvent) alEvents.get(i);
        }

        return events;
    }

    /**
     * This method retrieves the attribute that is tied to the specified key.
     * 
     * @param aKey The key that denotes the attribute.
     * @return Object Object that is the attribute identified by the key.
     * @since 1.0
     */
    public Object getAttribute(String aKey)
    {

        return getAttributeMap().get(aKey);
    }

    /**
     * This method returns an iterator over the keys of the attributes.
     * 
     * @since 1.0
     * @return Iterator Iterator over the attribute keys.
     */
    public Iterator getAttributeKeys()
    {

        Iterator it = getAttributeMap().keySet().iterator();

        return it;
    }

    /**
     * This method returns the attribute map for the current event.
     * 
     * @return HashMap Map of attributes.
     * @since 1.0
     */
    public Map getAttributeMap()
    {

        if (mAttribMap == null)
        {
            mAttribMap = new LinkedHashMap();
        }

        return mAttribMap;
    }

    /**
     * This method returns the event date of the current event.
     * 
     * @return String The event date as a string.
     * @since 1.0
     */
    public String getEventDate()
    {

        return (String) getAttribute(TIME_ATTRIB);
    }

    /**
     * This method returns the event Id of the current event.
     * 
     * @return String that is the event Id
     * @since 1.0
     */
    public String getEventId()
    {

        return (String) getAttribute(EVENT_ID_ATTRIB);
    }

    /**
     * This method provides a way to modify an attribute of the log event instance.
     * 
     * @param aKey Key identifying the attribute that needs to be changed.
     * @param aNewValue The new value that should replace the old one.
     * @throws LoggingException Exception thrown if key is null.
     * @since 1.0
     */
    public void modifyAttribute(String aKey, Object aNewValue)
    {

        if (aKey == null)
        {
            throw new LoggingException("Key cannot be null");
        }

        Map attribMap = getAttributeMap();

        // For the attribute map, just put the new value in. The old value will
        // be replaced.
        if (attribMap.containsKey(aKey))
        {
            attribMap.put(aKey, aNewValue);
        }

    }

    /**
     * This method removes the attribute that is tied to the specified key and returns it.
     * 
     * @param aKey The key that denotes the attribute.
     * @return Object Object that is the attribute identified by the key.
     * @throws LoggingException Exception thrown if key is null.
     * @since 1.0
     */
    public Object removeAttribute(String aKey)
    {

        if (aKey == null)
        {
            throw new LoggingException("Key cannot be null");
        }

        // remove the key from the attribute hashmap
        return getAttributeMap().remove(aKey);
    }

    /**
     * This method sets the list of associated events for the current event.
     * 
     * @param aAssocEvents Description
     * @since 1.0
     */
    public void setAssociatedEvents(ArrayList aAssocEvents)
    {
        mAssocEvents = aAssocEvents;
    }

    /**
     * Returns the string version of the log event including its attributes.
     * 
     * @since 1.0
     * @return String The string version of the log event.
     */
    public String toString()
    {

        // build a string of these internal events.
        String internalEvents = getAssociatedEventIds();

        if (internalEvents.length() != 0)
        {

            // add the internal events as an attribute of the LogEvent.
            addAttribute(INTERNAL_EVENTS_ATTRIB, internalEvents);
        }

        return getAttributeMap().toString();
    }

    /**
     * This method generates a random event Id that is associated with the event.
     * 
     * @return String that is the new event Id
     * @since 1.0
     */
    private String genEventId()
    {

        String eventId = null;
        Double d = new Double(Math.random());
        String sEventIdCandidate = d.toString();

        try
        {

            int startIndex = sEventIdCandidate.indexOf(".") + 1;
            eventId = sEventIdCandidate.substring(startIndex, startIndex + EVENT_ID_LENGTH);

            // we do this to eliminate leading zeroes
            Long id = new Long(eventId);
            eventId = id.toString();
        }
        catch (StringIndexOutOfBoundsException e)
        {
            eventId = genEventId();
        }

        return eventId;
    }

    /**
     * This is the private method that will return the list of associated events.
     * 
     * @since 1.0
     * @return ArrayList List of associated events.
     */
    private ArrayList getAssociatedEvents()
    {

        if (mAssocEvents == null)
        {
            mAssocEvents = new ArrayList();
        }

        return mAssocEvents;
    }
    
    /**
	 * 
	 * @param toolCodePlanId
	 * @return
	 * @since 1.0
	 */
	public LogEvent addToolCodeAndPlanId(String toolCodePlanId)
	{
		throw new UnsupportedOperationException("This operation is not supported for instances of type LogEvent. Please use ROIEligibilityLogEvent instead.");
	}
}