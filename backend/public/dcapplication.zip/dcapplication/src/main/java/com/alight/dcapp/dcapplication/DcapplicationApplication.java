package com.alight.dcapp.dcapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DcapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DcapplicationApplication.class, args);
	}

}
