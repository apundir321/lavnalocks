package com.hewitt.cat.fndt.utils.logging;

/* ====================================================================
 * 
 * Copyright (c) 2003-2005 Hewitt Associates, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Hewitt Associates, Inc. You shall not
 * disclose such Confidential Information.
 * 
 * ==================================================================== */


/**
 * Exception class for any exceptions that need to be thrown inside the logging package.
 * 
 * @hahistory 03/29/2004 a29362 Created
 * @since 1.0
 */
public class LoggingException extends RuntimeException
{

    /**
     * Constructor which takes in the message describing why this exception is being thrown.
     * 
     * @param aMessage reason why exception was thrown
     * @since 1.0
     */
    public LoggingException(String aMessage)
    {
        super(aMessage);
    }

    /**
     * Constructor which takes in a message describing why this exception is being thrown and a
     * <code>Throwable</code> which is the root cause for the exception. This gives a nesting of exceptions in
     * case one exception triggers another.
     * 
     * @param aMessage reason exception was thrown
     * @param aRootThrowable root cause for the exception
     * @since 1.0
     */
    public LoggingException(String aMessage, Throwable aRootThrowable)
    {
        super(aMessage, aRootThrowable);
    }
}
